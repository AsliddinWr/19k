<?php
require __DIR__ . '/bot.php';

global $WEBHOOK_SECRET;

if ($WEBHOOK_SECRET) {
    $secretHeader = $_SERVER['HTTP_X_TELEGRAM_BOT_API_SECRET_TOKEN'] ?? '';
    if (!hash_equals($WEBHOOK_SECRET, $secretHeader)) {
        http_response_code(403);
        echo 'Forbidden';
        exit;
    }
}

$update = json_decode(file_get_contents('php://input'), true);

if (!is_array($update)) {
    http_response_code(200);
    echo 'OK';
    exit;
}

$message = $update['message'] ?? null;

if ($message) {
    $chatId = $message['chat']['id'] ?? null;
    $text = $message['text'] ?? '';

    if ($chatId && $text === '/start') {
        send_start_message($chatId);
    }

    if ($chatId && isset($message['web_app_data']['data'])) {
        handle_web_app_data($chatId, $message['web_app_data']['data']);
    }
}

http_response_code(200);
echo 'OK';
