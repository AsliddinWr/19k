<?php
// Simple config loader. On real hosting, prefer real server environment variables.

function env_value(string $key, ?string $default = null): ?string
{
    $value = getenv($key);
    if ($value !== false && $value !== '') {
        return $value;
    }

    $envFile = __DIR__ . '/.env';
    if (!file_exists($envFile)) {
        return $default;
    }

    $lines = file($envFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach ($lines as $line) {
        $line = trim($line);
        if ($line === '' || str_starts_with($line, '#') || !str_contains($line, '=')) {
            continue;
        }

        [$name, $val] = explode('=', $line, 2);
        if (trim($name) === $key) {
            return trim($val, " \t\n\r\0\x0B\"'");
        }
    }

    return $default;
}

const ADMIN_IDS = [
    // 123456789, // your Telegram user ID
];

$BOT_TOKEN = env_value('BOT_TOKEN');
$WEB_APP_URL = env_value('WEB_APP_URL');
$WEBHOOK_SECRET = env_value('WEBHOOK_SECRET');

if (!$BOT_TOKEN || !$WEB_APP_URL) {
    http_response_code(500);
    echo 'BOT_TOKEN yoki WEB_APP_URL topilmadi';
    exit;
}
