<?php
require __DIR__ . '/bot.php';

global $WEBHOOK_SECRET;

$webhookUrl = $_GET['url'] ?? '';

if (!$webhookUrl) {
    echo "Usage: https://your-php-server.com/set-webhook.php?url=https://your-php-server.com/webhook.php";
    exit;
}

$payload = ['url' => $webhookUrl];

if ($WEBHOOK_SECRET) {
    $payload['secret_token'] = $WEBHOOK_SECRET;
}

header('Content-Type: application/json; charset=utf-8');
echo json_encode(telegram_api('setWebhook', $payload), JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
