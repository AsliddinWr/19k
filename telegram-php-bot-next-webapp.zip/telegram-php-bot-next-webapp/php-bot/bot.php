<?php
require __DIR__ . '/config.php';

function telegram_api(string $method, array $payload = []): array
{
    global $BOT_TOKEN;

    $url = "https://api.telegram.org/bot{$BOT_TOKEN}/{$method}";

    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_HTTPHEADER => ['Content-Type: application/json'],
        CURLOPT_POSTFIELDS => json_encode($payload, JSON_UNESCAPED_UNICODE),
        CURLOPT_TIMEOUT => 15,
    ]);

    $response = curl_exec($ch);
    $error = curl_error($ch);
    curl_close($ch);

    if ($response === false) {
        return ['ok' => false, 'description' => $error ?: 'curl error'];
    }

    $data = json_decode($response, true);
    return is_array($data) ? $data : ['ok' => false, 'description' => 'Invalid Telegram response'];
}

function send_message(int|string $chatId, string $text, array $extra = []): array
{
    return telegram_api('sendMessage', array_merge([
        'chat_id' => $chatId,
        'text' => $text,
        'parse_mode' => 'HTML',
    ], $extra));
}

function send_start_message(int|string $chatId): array
{
    global $WEB_APP_URL;

    return send_message(
        $chatId,
        "Assalomu alaykum!\n\nWeb App panelni ochish uchun pastdagi tugmani bosing 👇",
        [
            'reply_markup' => [
                'inline_keyboard' => [
                    [
                        [
                            'text' => '🚀 Web App ni ochish',
                            'web_app' => ['url' => $WEB_APP_URL],
                        ],
                    ],
                ],
            ],
        ]
    );
}

function handle_web_app_data(int|string $chatId, string $rawData): array
{
    $decoded = json_decode($rawData, true);

    if (!is_array($decoded)) {
        return send_message($chatId, "Web App dan ma’lumot keldi:\n\n<code>" . htmlspecialchars($rawData) . "</code>");
    }

    $type = $decoded['type'] ?? 'unknown';
    $payload = $decoded['payload'] ?? [];

    if ($type === 'gift_create') {
        $caseName = htmlspecialchars((string)($payload['caseName'] ?? '-'));
        $giftName = htmlspecialchars((string)($payload['giftName'] ?? '-'));
        $price = htmlspecialchars((string)($payload['price'] ?? '-'));
        $note = htmlspecialchars((string)($payload['note'] ?? '-'));

        // Shu joyda databasega saqlashingiz mumkin.
        // Masalan: gifts jadvaliga caseName, giftName, price, note ni INSERT qilish.

        return send_message(
            $chatId,
            "✅ <b>Sovg‘a ma’lumoti qabul qilindi</b>\n\n" .
            "📦 Case: <b>{$caseName}</b>\n" .
            "🎁 Sovg‘a: <b>{$giftName}</b>\n" .
            "💰 Yechish narxi: <b>{$price}</b>\n" .
            "📝 Izoh: {$note}"
        );
    }

    return send_message($chatId, "Web App data:\n<code>" . htmlspecialchars(json_encode($decoded, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT)) . "</code>");
}
